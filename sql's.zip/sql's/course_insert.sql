insert	into course (code,description) values ('MATH', 'Matemaatika');
insert	into course (code,description) values ('ENG', 'English');
insert	into course (code,description) values ('FOTO', 'Fotografia');

create table groupcourse (
coursecode varchar(8),
groupcode varchar(8),
primary key(coursecode,groupcode),
foreign key (coursecode) reference course(code),
foreign key (groupcode) reference stgroup(code)
);