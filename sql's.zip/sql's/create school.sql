create database school;

use school;

create table stgroup(
code varchar(8) not null,
description varchar(256),
primary key (code)
);

insert into stgroup(code, description) values ('ta-22v', '2022 sisseastunud tarkvara arendajad (vene)');
insert into stgroup(code, description) values ('MM-22', '2022 multimeedia');
insert into stgroup(code, description) values ('ta-24', '2024 sisseastunud');
insert into stgroup(code, description) values ('ta-25v', '2024 tarkvara arendajad (eesti)');

-- select  * from stgroup;

create table student(
code bigint not null,
firstname varchar(64),
lastname  varchar(64),
groupcode  varchar(8),
email varchar(64),
primary key(code),
foreign key (groupcode) references stgroup(code)
);

insert into student (code, firstname, lastname, groupcode, email) values (506375048244, 'Daxak', 'Till', 'ta-23', 'daxak.till@gmail.com');
insert into student (code, firstname, lastname, groupcode, email) values (535755048244, 'Alex', 'Smirnov', 'ta-22v', 'alex.smir@gmail.com');

create table courses(
id int(8) not null primary key auto_increment,
description varchar(256),
groupcode int(8) not null,
foreign key (id) references course(id),
foreign key (groupcode) references stgroup(code)
);

