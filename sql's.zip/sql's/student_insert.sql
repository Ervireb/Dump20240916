insert into student (code, firstname, lastname, groupcode, email)
values (503155048244, 'Albert', 'Nork', 'mm-23', 'fd@gamil.ee');

insert into student (code, firstname, lastname, groupcode, email)
values (343154252244, 'Ervin', 'Rebane', 'mm-23', 'fd@gamil.com');

insert into student (code, firstname, lastname, groupcode, email)
values (546159674864, 'Sergei', 'Suika', 'mv-23v', 'Suika@serlov.ru');

insert into student (code, firstname, lastname, groupcode, email)
values (576034328044, 'Fedor', 'Fedotov', 'mv-22', 'Fedor@gamil.ru');

insert into student (code, firstname, lastname, groupcode, email)
values (504423458548, 'Nikolai', 'Tamm', 'mm-22v', 'online@post.net');

insert into student (code, firstname, lastname, groupcode, email)
values (653286550474, 'Kukk', 'Datlov', 'ta-22', 'Hbo@gamil.com');

insert into student (code, firstname, lastname, groupcode, email)
values (503155673878, 'David', 'Janes', 'ta-21', 'Janes@gamil.co.uk');

insert into student (code, firstname, lastname, groupcode, email)
values (571565386984, 'Lamb', 'White', 'ta-21v', 'lamb@outlook.com');

